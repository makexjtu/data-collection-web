<template>
  <el-card>
    <div class="success-top" >
      <div class="success-top-style">
        <img style="margin-left: 18px" src="../../assets/images/通过.png"  alt=""/>
        <h2>操作成功！</h2>
      </div>
    </div>
  </el-card>
</template>

<script>
    export default {
        name: "SuccessPage"
    }
</script>

<style scoped>
  .success-top{
    height: 600px;
  }
  .success-top-style{
    padding-top: 10px;
    width: 120px;
    margin: 0 auto;
  }

</style>
