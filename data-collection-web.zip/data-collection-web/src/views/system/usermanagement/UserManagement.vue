<template>
  <el-card>
    <h2>待开发中。。。</h2>
  </el-card>
</template>

<script>
  export default {
    data(){
      return{
      }
    },
    computed: {
    },
    created() {
    },
    methods:{

    }
  }
</script>

<style lang="less" scoped>

</style>
