//全局的静态配置文件
window.globalData = {
    //可以定义一些在打包后可能需要频繁改动的变量。
    baseUrl:"http://192.168.0.127:8021"
}
//项目中获取方式  window.globalData.参数名称